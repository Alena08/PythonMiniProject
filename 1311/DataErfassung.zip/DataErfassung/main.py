import tkinter as tk
from tkinter import ttk, PhotoImage

from person import Person

root = tk.Tk()

def submit():
    # entries
    p = Person()
    # messageBox ("Person Data",p)

image_frame = tk.Frame(root, width=50, height=50)
image_frame.grid(column=0, row=0, rowspan=5)
# image load
image = PhotoImage(file="person_bild.png")
image = image.subsample(5,5)
# show image
image_lable = tk.Label(image_frame, image=image)
image_lable.pack(padx=5, pady=5)

# tk.Label(root, text="Name:").grid(column=1, row=0)
# tk.Label(root, text="Gender:").grid(column=1, row=1)
# tk.Label(root, text="Eye Color:").grid(column=1, row=2)
# tk.Label(root, text="Height (cm):").grid(column=1, row=3)
# tk.Label(root, text="Weight (kg):").grid(column=1, row=4)

for i,elemnt in enumerate(["Name","Gender","Eye Color","Height (cm)","Weight (kg)"]):
    tk.Label(root, text=f"{elemnt}:").grid(column=1, row=i)

name_entry = tk.Entry()
name_entry.grid(column=2, row=0, columnspan=2)

gender = tk.StringVar()
gender_combx = ttk.Combobox(root,width=20, textvariable=gender)
gender_combx['values']=("Male", "Female")
gender_combx.grid(column=2, row=1, columnspan=2)
gender_combx.current(0)

eyeColor = tk.StringVar()
eyeColor_combx = ttk.Combobox(root,width=20, textvariable=eyeColor)
eyeColor_combx['values']=("Brown","Black","Blue","Green","Red","Hony","Olive")
eyeColor_combx.grid(column=2,row=2, columnspan=2)

height_entry = tk.Entry()
height_entry.grid(column=2, row=3, columnspan=2)

weight_entry = tk.Entry()
weight_entry.grid(column=2, row=4, columnspan=2)

submit_btn = tk.Button(root, text="Submit")
submit_btn.grid(column=3, row=5, columnspan=2)
root.mainloop()